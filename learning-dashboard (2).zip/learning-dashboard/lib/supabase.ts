import { createClient as createSupabaseClient } from '@supabase/supabase-js'

// Using the simple supabase-js client since we only need server-side reads.
// The new Supabase publishable key works as the anon key here.
export function createClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
